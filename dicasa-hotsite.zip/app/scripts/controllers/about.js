'use strict';

/**
 * @ngdoc function
 * @name diCasaApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the diCasaApp
 */
angular.module('diCasaApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
