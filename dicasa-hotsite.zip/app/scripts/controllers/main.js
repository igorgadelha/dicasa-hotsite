'use strict';

/**
 * @ngdoc function
 * @name diCasaApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the diCasaApp
 */
angular.module('diCasaApp')
  .controller('MainCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
